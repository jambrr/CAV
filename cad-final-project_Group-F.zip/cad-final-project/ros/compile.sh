#!/bin/bash
set -e 

cd /host/ros
catkin_make
