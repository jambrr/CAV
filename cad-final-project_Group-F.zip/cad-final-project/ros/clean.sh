#!/bin/bash
cd /host/ros && rm -rf build devel
