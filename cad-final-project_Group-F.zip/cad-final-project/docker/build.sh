#!/bin/bash

docker build -f Dockerfile -t 360lab/cad-final-project .
